# ErgoDox EZ Colemak Configuration

Colemak layout with same layers as default ergodox ez keymap.

